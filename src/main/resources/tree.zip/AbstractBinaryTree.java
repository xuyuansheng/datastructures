package com.java.study.datastructuresalgorithms.basisdatastructure.tree;

/**
 * 二叉树抽像类
 *
 * @author Mr.Xu
 * @date 2020/9/10 15:26
 */
public abstract class AbstractBinaryTree<T> implements Tree<T> {


}
